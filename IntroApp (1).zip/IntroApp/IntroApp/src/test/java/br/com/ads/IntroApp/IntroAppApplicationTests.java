package br.com.ads.IntroApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
